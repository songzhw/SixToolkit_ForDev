package ca.six.mall.biz.splash

import android.os.Bundle
import ca.six.mall.R
import ca.six.mall.core.BaseActivity

class SplashActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
    }
}
