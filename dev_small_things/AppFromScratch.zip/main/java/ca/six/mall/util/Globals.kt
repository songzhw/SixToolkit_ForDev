package ca.six.mall.util

object Globals {
}
