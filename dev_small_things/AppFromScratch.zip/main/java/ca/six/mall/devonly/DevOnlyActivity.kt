package ca.six.mall.devonly

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import ca.six.mall.R

class DevOnlyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dev_only)
    }

}