package ca.six.mall.devonly

class DevOnlyPageInfo(var name : String, var clazz: Class<*>) {
}